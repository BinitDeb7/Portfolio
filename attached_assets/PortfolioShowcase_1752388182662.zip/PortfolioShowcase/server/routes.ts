import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { insertContactSchema } from "@shared/schema";
import nodemailer from "nodemailer";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission endpoint
  app.post("/api/contact", async (req, res) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      
      // Create transporter for sending emails
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: process.env.EMAIL_USER || 'binitdeb5396@gmail.com',
          pass: process.env.EMAIL_PASS || 'your-app-password'
        }
      });

      // Email to yourself (notification)
      const mailOptions = {
        from: process.env.EMAIL_USER || 'binitdeb5396@gmail.com',
        to: 'binitdeb5396@gmail.com',
        subject: `Portfolio Contact: ${contactData.subject}`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #333; border-bottom: 2px solid #4F46E5; padding-bottom: 10px;">
              New Contact Form Submission
            </h2>
            <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="color: #4F46E5; margin-top: 0;">Contact Details</h3>
              <p><strong>Name:</strong> ${contactData.name}</p>
              <p><strong>Email:</strong> ${contactData.email}</p>
              <p><strong>Subject:</strong> ${contactData.subject}</p>
            </div>
            <div style="background: #ffffff; padding: 20px; border-left: 4px solid #4F46E5; margin: 20px 0;">
              <h3 style="color: #333; margin-top: 0;">Message</h3>
              <p style="line-height: 1.6;">${contactData.message}</p>
            </div>
            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
              <p style="color: #666; font-size: 14px;">
                This message was sent from your portfolio contact form.
                <br>
                Reply directly to this email to respond to ${contactData.name}.
              </p>
            </div>
          </div>
        `
      };

      // Confirmation email to the sender
      const confirmationOptions = {
        from: process.env.EMAIL_USER || 'binitdeb5396@gmail.com',
        to: contactData.email,
        subject: 'Thank you for contacting me!',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #4F46E5; border-bottom: 2px solid #4F46E5; padding-bottom: 10px;">
              Thank you for reaching out!
            </h2>
            <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <p>Hi ${contactData.name},</p>
              <p>Thank you for contacting me through my portfolio website. I have received your message and will get back to you as soon as possible.</p>
            </div>
            <div style="background: #ffffff; padding: 20px; border-left: 4px solid #4F46E5; margin: 20px 0;">
              <h3 style="color: #333; margin-top: 0;">Your Message Summary</h3>
              <p><strong>Subject:</strong> ${contactData.subject}</p>
              <p><strong>Message:</strong></p>
              <p style="line-height: 1.6;">${contactData.message}</p>
            </div>
            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
              <p style="color: #666; font-size: 14px;">
                Best regards,<br>
                <strong>Binit Deb</strong><br>
                Full Stack Developer<br>
                <a href="mailto:binitdeb5396@gmail.com" style="color: #4F46E5;">binitdeb5396@gmail.com</a>
              </p>
            </div>
          </div>
        `
      };

      // Send both emails
      await transporter.sendMail(mailOptions);
      await transporter.sendMail(confirmationOptions);

      res.json({ 
        success: true, 
        message: "Message sent successfully! You will receive a confirmation email shortly." 
      });
    } catch (error) {
      console.error("Contact form error:", error);
      res.status(500).json({ 
        success: false, 
        message: "Failed to send message. Please try again or contact me directly." 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

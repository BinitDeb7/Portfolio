import { Button } from "@/components/ui/button";
import { Github, Linkedin, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-100 dark:bg-slate-900 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="mb-8">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Binit Deb</h3>
            <p className="text-gray-700 dark:text-gray-300 max-w-md mx-auto">
              Full Stack Developer passionate about creating innovative solutions and building the future through code.
            </p>
          </div>
          
          <div className="flex justify-center space-x-6 mb-8">
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
              onClick={() => window.open("https://github.com/BinitDeb7", "_blank")}
            >
              <Github className="h-6 w-6" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
              onClick={() => window.open("https://linkedin.com/in/binitdeb", "_blank")}
            >
              <Linkedin className="h-6 w-6" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
              onClick={() => window.location.href = "mailto:binitdeb5396@gmail.com"}
            >
              <Mail className="h-6 w-6" />
            </Button>
          </div>
          
          <div className="border-t border-gray-300 dark:border-gray-600 pt-8">
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              © 2024 Binit Deb. All rights reserved. Made with ❤️ using modern web technologies.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

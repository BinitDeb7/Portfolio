import { Button } from "@/components/ui/button";
import { Mail, Code, Github, Linkedin, Phone, ChevronDown } from "lucide-react";

export default function Hero() {
  const handleEmailClick = () => {
    window.location.href = "mailto:binitdeb5396@gmail.com";
  };

  const scrollToProjects = () => {
    const element = document.querySelector("#projects");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="min-h-screen gradient-bg flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 bg-black/20"></div>
      
      {/* Floating Elements */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-white/10 rounded-full animate-bounce-gentle"></div>
      <div className="absolute bottom-20 right-10 w-16 h-16 bg-white/10 rounded-full animate-bounce-gentle" style={{ animationDelay: "1s" }}></div>
      <div className="absolute top-1/2 right-20 w-12 h-12 bg-white/10 rounded-full animate-bounce-gentle" style={{ animationDelay: "2s" }}></div>
      
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto animate-fade-in">
        <div className="mb-8">
          <h1 className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
            Binit Deb
          </h1>
          <h2 className="text-2xl md:text-3xl font-light mb-6 text-gray-200">
            Full Stack Developer & CS Student
          </h2>
          <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Passionate about creating innovative web applications using modern technologies. 
            Currently pursuing B.Tech in Computer Science & Engineering.
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
          <Button 
            onClick={handleEmailClick}
            className="inline-flex items-center px-8 py-3 bg-gradient-to-r from-primary to-purple-600 hover:scale-105 transition-transform shadow-xl text-white"
          >
            <Mail className="mr-2 h-4 w-4" />
            Get In Touch
          </Button>
          <Button 
            onClick={scrollToProjects}
            variant="outline"
            className="inline-flex items-center px-8 py-3 glass-effect text-white border-white/20 hover:bg-white/20"
          >
            <Code className="mr-2 h-4 w-4" />
            View Projects
          </Button>
        </div>
        
        {/* Social Links */}
        <div className="flex justify-center space-x-6">
          <Button
            variant="ghost"
            size="icon"
            className="w-12 h-12 glass-effect rounded-full hover:bg-white/20 text-white"
            onClick={() => window.open("https://github.com/BinitDeb7", "_blank")}
          >
            <Github className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="w-12 h-12 glass-effect rounded-full hover:bg-white/20 text-white"
            onClick={() => window.open("https://linkedin.com/in/binitdeb", "_blank")}
          >
            <Linkedin className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="w-12 h-12 glass-effect rounded-full hover:bg-white/20 text-white"
            onClick={() => window.location.href = "tel:+918822443862"}
          >
            <Phone className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ChevronDown className="text-white text-2xl" />
      </div>
    </section>
  );
}

# Portfolio Website

## Overview

This is a full-stack portfolio website built with React, Express.js, and TypeScript. It's a single-page application showcasing a developer's professional profile with sections for about, experience, projects, skills, education, and contact information. The application includes a contact form that sends emails directly to the owner's email address.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **State Management**: React Query (TanStack Query) for server state
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Email**: Nodemailer for contact form functionality
- **Development**: Hot reload with Vite integration

## Key Components

### Frontend Components
- **Layout Components**: Navbar, Hero, About, Experience, Projects, Skills, Education, Contact, Footer
- **UI Components**: Comprehensive set of reusable components from shadcn/ui
- **Theme System**: Dark/light mode toggle with CSS variables
- **Form Handling**: React Hook Form with Zod validation
- **Animations**: CSS-based animations with Intersection Observer for scroll-triggered effects

### Backend Components
- **API Routes**: RESTful endpoints for contact form submission
- **Email Service**: Nodemailer integration for sending contact form emails
- **Database Schema**: User and contact tables with Drizzle ORM
- **Error Handling**: Centralized error handling middleware
- **Development Tools**: Request logging and error overlay

## Data Flow

1. **Contact Form Submission**: User fills out contact form → Form validation → API request to `/api/contact`
2. **Email Processing**: Server receives contact data → Validates with Zod schema → Sends formatted email via Nodemailer
3. **Database Operations**: Contact information stored in PostgreSQL via Drizzle ORM
4. **Response Handling**: Success/error responses sent back to client → Toast notifications displayed

## External Dependencies

### Core Dependencies
- **Database**: Neon PostgreSQL (serverless)
- **Email Service**: Gmail SMTP via Nodemailer
- **UI Framework**: Radix UI primitives
- **Validation**: Zod for schema validation
- **Date Handling**: date-fns for date manipulation

### Development Dependencies
- **Build Tools**: Vite, esbuild for production builds
- **Type Safety**: TypeScript with strict configuration
- **Code Quality**: ESLint, Prettier (implied by project structure)
- **Development Environment**: Replit-specific plugins and configurations

## Deployment Strategy

### Development Environment
- **Local Development**: `npm run dev` starts both frontend and backend with hot reload
- **Database Management**: `npm run db:push` for schema migrations
- **Type Checking**: `npm run check` for TypeScript validation

### Production Build
- **Frontend**: Vite builds React app to `dist/public`
- **Backend**: esbuild bundles Express server to `dist/index.js`
- **Static Assets**: Served from `dist/public` directory
- **Environment Variables**: Required for database URL and email credentials

### Configuration Requirements
- **DATABASE_URL**: PostgreSQL connection string for Drizzle
- **EMAIL_USER**: Gmail account for sending emails
- **EMAIL_PASS**: Gmail app password for SMTP authentication

The application follows a monorepo structure with shared TypeScript definitions and clear separation between client and server code. The build process creates a production-ready bundle that can be deployed to any Node.js hosting platform.
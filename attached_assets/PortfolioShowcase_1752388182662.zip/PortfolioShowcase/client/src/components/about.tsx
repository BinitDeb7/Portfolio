import { GraduationCap, Briefcase, Code, Award } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="portfolio-section bg-gray-50 dark:bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="section-title text-gray-900 dark:text-white">About Me</h2>
          <div className="section-subtitle"></div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="animate-slide-up">
            <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-6">Hello! I'm Binit Deb</h3>
            <div className="space-y-4 text-gray-700 dark:text-gray-300">
              <p>
                An analytical professional equipped with technical expertise and strong critical thinking skills. 
                I approach challenges with a positive attitude and determination to succeed, excelling both 
                independently and in collaboration with teams.
              </p>
              <p>
                Currently pursuing B.Tech in Computer Science & Engineering at Assam Downtown University, 
                I've gained hands-on experience through my internship at Myjobgrow, where I contributed to 
                developing and maintaining web applications using modern technologies.
              </p>
              <p>
                I'm passionate about creating innovative solutions and have worked on various projects 
                including AI-powered applications and full-stack e-commerce platforms.
              </p>
            </div>
            
            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="glass-effect p-4 rounded-lg">
                <h4 className="text-gray-900 dark:text-white font-semibold mb-2">Location</h4>
                <p className="text-gray-700 dark:text-gray-300">Guwahati, Assam, India</p>
              </div>
              <div className="glass-effect p-4 rounded-lg">
                <h4 className="text-gray-900 dark:text-white font-semibold mb-2">Email</h4>
                <p className="text-gray-700 dark:text-gray-300">binitdeb5396@gmail.com</p>
              </div>
            </div>
          </div>
          
          <div className="animate-slide-up" style={{ animationDelay: "0.2s" }}>
            <div className="relative">
              <div className="glass-effect p-8 rounded-2xl">
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-to-r from-primary to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <GraduationCap className="h-8 w-8 text-white" />
                    </div>
                    <h4 className="text-gray-900 dark:text-white font-semibold">Education</h4>
                    <p className="text-gray-700 dark:text-gray-300 text-sm">B.Tech CSE Student</p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Briefcase className="h-8 w-8 text-white" />
                    </div>
                    <h4 className="text-gray-900 dark:text-white font-semibold">Experience</h4>
                    <p className="text-gray-700 dark:text-gray-300 text-sm">Web Development</p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-to-r from-yellow-500 to-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Code className="h-8 w-8 text-white" />
                    </div>
                    <h4 className="text-gray-900 dark:text-white font-semibold">Projects</h4>
                    <p className="text-gray-700 dark:text-gray-300 text-sm">5+ Completed</p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Award className="h-8 w-8 text-white" />
                    </div>
                    <h4 className="text-gray-900 dark:text-white font-semibold">Certifications</h4>
                    <p className="text-gray-700 dark:text-gray-300 text-sm">2+ Achieved</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

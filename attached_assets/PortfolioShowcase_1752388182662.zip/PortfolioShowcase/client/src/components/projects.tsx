import { Button } from "@/components/ui/button";
import { ExternalLink, Github, Dumbbell, ShoppingCart } from "lucide-react";

export default function Projects() {
  const projects = [
    {
      id: 1,
      title: "AI Fitness Trainer",
      description: "Developed a web application using Next.js that leverages AI to provide personalized fitness recommendations and track user progress. Features exercise guidance, workout planning, and performance analysis with machine learning algorithms.",
      icon: <Dumbbell className="h-16 w-16 text-white" />,
      technologies: ["Next.js", "AI/ML", "Data Visualization", "Real-time Monitoring"],
      liveUrl: "https://ai-fitness-trainer-zeta.vercel.app/",
      githubUrl: "https://github.com/BinitDeb7",
      gradient: "from-blue-500 to-purple-600",
      status: "Latest"
    },
    {
      id: 2,
      title: "E-commerce Platform",
      description: "Complete e-commerce application utilizing React, Node.js, Express, and MongoDB. Features seamless product catalog browsing, secure authentication, shopping cart functionality, and integrated payment processing with real-time inventory management.",
      icon: <ShoppingCart className="h-16 w-16 text-white" />,
      technologies: ["React", "Node.js", "MongoDB", "Express"],
      liveUrl: "https://fullstack-ecommerce.netlify.app/",
      githubUrl: "https://github.com/BinitDeb7",
      gradient: "from-green-500 to-blue-600",
      status: "Featured"
    }
  ];

  return (
    <section id="projects" className="portfolio-section bg-gray-50 dark:bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="section-title text-gray-900 dark:text-white">Featured Projects</h2>
          <div className="section-subtitle"></div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div 
              key={project.id}
              className="project-card animate-slide-up"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <div className={`mb-6 h-48 bg-gradient-to-br ${project.gradient} rounded-xl flex items-center justify-center`}>
                {project.icon}
              </div>
              
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{project.title}</h3>
                <span className={`px-3 py-1 ${project.status === 'Latest' ? 'bg-green-500/20 text-green-300' : 'bg-blue-500/20 text-blue-300'} rounded-full text-sm`}>
                  {project.status}
                </span>
              </div>
              
              <p className="text-gray-700 dark:text-gray-300 mb-6">
                {project.description}
              </p>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {project.technologies.map((tech, techIndex) => (
                  <span 
                    key={techIndex}
                    className={`px-3 py-1 rounded-full text-sm ${
                      techIndex === 0 ? 'bg-blue-500/20 text-blue-300' :
                      techIndex === 1 ? 'bg-green-500/20 text-green-300' :
                      techIndex === 2 ? 'bg-purple-500/20 text-purple-300' :
                      'bg-yellow-500/20 text-yellow-300'
                    }`}
                  >
                    {tech}
                  </span>
                ))}
              </div>
              
              <div className="flex space-x-4">
                <Button 
                  onClick={() => window.open(project.liveUrl, "_blank")}
                  className={`flex-1 bg-gradient-to-r ${project.gradient} hover:scale-105 transition-transform text-white`}
                >
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Live Demo
                </Button>
                <Button 
                  onClick={() => window.open(project.githubUrl, "_blank")}
                  variant="outline"
                  className="flex-1 glass-effect text-white border-white/20 hover:bg-white/20"
                >
                  <Github className="mr-2 h-4 w-4" />
                  Code
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

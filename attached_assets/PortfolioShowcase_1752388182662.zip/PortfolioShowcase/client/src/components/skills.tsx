import { useEffect, useRef } from "react";

export default function Skills() {
  const skillsRef = useRef<HTMLDivElement>(null);

  const technicalSkills = [
    { name: "JavaScript", level: 90, color: "from-yellow-400 to-orange-500" },
    { name: "React / Next.js", level: 85, color: "from-blue-400 to-blue-600" },
    { name: "Node.js", level: 80, color: "from-green-400 to-green-600" },
    { name: "Python", level: 75, color: "from-blue-500 to-yellow-500" },
    { name: "MongoDB / MySQL", level: 70, color: "from-green-500 to-blue-500" },
  ];

  const technologies = [
    { name: "HTML5", icon: "🌐", color: "from-orange-500 to-red-600" },
    { name: "CSS3", icon: "🎨", color: "from-blue-500 to-blue-700" },
    { name: "JavaScript", icon: "⚡", color: "from-yellow-400 to-yellow-600" },
    { name: "React", icon: "⚛️", color: "from-blue-400 to-blue-600" },
    { name: "Node.js", icon: "🟢", color: "from-green-500 to-green-700" },
    { name: "Python", icon: "🐍", color: "from-blue-600 to-yellow-500" },
    { name: "Git", icon: "📚", color: "from-gray-700 to-gray-900" },
    { name: "MongoDB", icon: "🍃", color: "from-green-600 to-blue-600" },
    { name: "MySQL", icon: "🐬", color: "from-blue-500 to-orange-500" },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const progressBars = entry.target.querySelectorAll('.skill-progress');
            progressBars.forEach((bar) => {
              const progressElement = bar as HTMLElement;
              const width = progressElement.style.width;
              progressElement.style.width = '0%';
              setTimeout(() => {
                progressElement.style.width = width;
              }, 500);
            });
          }
        });
      },
      { threshold: 0.1 }
    );

    if (skillsRef.current) {
      observer.observe(skillsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="skills" className="portfolio-section bg-white dark:bg-slate-800" ref={skillsRef}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="section-title text-gray-900 dark:text-white">Skills & Technologies</h2>
          <div className="section-subtitle"></div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Technical Skills */}
          <div className="animate-slide-up">
            <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-8 text-center">Technical Skills</h3>
            <div className="space-y-6">
              {technicalSkills.map((skill, index) => (
                <div key={skill.name} className="skill-item">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-900 dark:text-white font-medium">{skill.name}</span>
                    <span className="text-primary">{skill.level}%</span>
                  </div>
                  <div className="skill-bar">
                    <div 
                      className={`skill-progress bg-gradient-to-r ${skill.color} h-3 rounded-full`}
                      style={{ width: `${skill.level}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Technology Stack */}
          <div className="animate-slide-up" style={{ animationDelay: "0.2s" }}>
            <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-8 text-center">Technology Stack</h3>
            <div className="grid grid-cols-3 gap-6">
              {technologies.map((tech, index) => (
                <div key={tech.name} className="text-center group">
                  <div className={`w-16 h-16 mx-auto mb-3 bg-gradient-to-r ${tech.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <span className="text-2xl">{tech.icon}</span>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300 text-sm">{tech.name}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

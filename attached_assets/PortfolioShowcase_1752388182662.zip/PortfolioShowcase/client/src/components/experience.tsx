import { CheckCircle } from "lucide-react";

export default function Experience() {
  return (
    <section id="experience" className="portfolio-section bg-white dark:bg-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="section-title text-gray-900 dark:text-white">Experience</h2>
          <div className="section-subtitle"></div>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="glass-effect p-8 rounded-2xl animate-slide-up">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Web Development Intern</h3>
                <p className="text-primary font-semibold">Myjobgrow</p>
                <p className="text-gray-400">Virtual | July 2024 - November 2024</p>
              </div>
              <div className="mt-4 md:mt-0">
                <span className="inline-block px-4 py-2 bg-gradient-to-r from-green-500 to-blue-600 text-white rounded-full text-sm font-semibold">
                  4 Months
                </span>
              </div>
            </div>
            
            <div className="space-y-4 text-gray-700 dark:text-gray-300">
              <div className="flex items-start space-x-3">
                <CheckCircle className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                <p>Participated in developing and maintaining web applications using HTML, CSS, and JavaScript, contributing to ongoing project enhancements.</p>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                <p>Participated in front-end development efforts by designing user interfaces with a focus on improving website features and user experience.</p>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                <p>Assisted in developing web applications using frameworks such as React and Angular to improve front-end performance and functionality.</p>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                <p>Contributed to collaborative projects by coordinating with developers to address project goals and adhere to technical requirements.</p>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                <p>Enhanced cross-browser compatibility by testing and refining web applications, ensuring consistent user experiences across multiple platforms.</p>
              </div>
            </div>
            
            <div className="mt-6 flex flex-wrap gap-2">
              <span className="px-3 py-1 bg-primary/20 text-primary rounded-full text-sm">HTML</span>
              <span className="px-3 py-1 bg-primary/20 text-primary rounded-full text-sm">CSS</span>
              <span className="px-3 py-1 bg-primary/20 text-primary rounded-full text-sm">JavaScript</span>
              <span className="px-3 py-1 bg-primary/20 text-primary rounded-full text-sm">React</span>
              <span className="px-3 py-1 bg-primary/20 text-primary rounded-full text-sm">Angular</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

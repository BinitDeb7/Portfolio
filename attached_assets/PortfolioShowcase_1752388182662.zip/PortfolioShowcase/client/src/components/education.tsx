import { GraduationCap, School, Award, Tag } from "lucide-react";

export default function Education() {
  const education = [
    {
      degree: "B.Tech, Computer Science & Engineering",
      institution: "Assam Downtown University",
      location: "Guwahati, Assam",
      period: "2022 - 2026",
      description: "Currently pursuing undergraduate degree in Computer Science & Engineering with focus on software development, data structures, algorithms, and modern web technologies.",
      icon: <GraduationCap className="h-6 w-6 text-white" />,
      gradient: "from-blue-500 to-purple-600"
    },
    {
      degree: "Senior Secondary (XII), CBSE Science",
      institution: "Kendriya Vidyalaya NIT Silchar",
      location: "",
      period: "2021",
      description: "Completed higher secondary education with Science stream, laying the foundation for engineering studies with strong mathematical and analytical skills.",
      icon: <School className="h-6 w-6 text-white" />,
      gradient: "from-green-500 to-blue-600"
    }
  ];

  const certifications = [
    {
      title: "Technology Job Simulation",
      organization: "Virtual Platform",
      date: "June 2025",
      description: "Completed comprehensive technology job simulation covering real-world scenarios, problem-solving techniques, and industry best practices.",
      icon: <Award className="h-6 w-6 text-white" />,
      gradient: "from-yellow-500 to-red-600"
    },
    {
      title: "Course On Computer Concepts (CCC)",
      organization: "NIELIT",
      date: "August 2019",
      description: "Fundamental computer literacy certification covering basic computer operations, software applications, and digital literacy skills.",
      icon: <Tag className="h-6 w-6 text-white" />,
      gradient: "from-purple-500 to-pink-600"
    }
  ];

  return (
    <section className="portfolio-section bg-gray-50 dark:bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="section-title text-gray-900 dark:text-white">Education & Certifications</h2>
          <div className="section-subtitle"></div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Education */}
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-6">Education</h3>
            
            {education.map((edu, index) => (
              <div key={index} className="glass-effect p-6 rounded-xl animate-slide-up" style={{ animationDelay: `${index * 0.1}s` }}>
                <div className="flex items-start space-x-4">
                  <div className={`w-12 h-12 bg-gradient-to-r ${edu.gradient} rounded-full flex items-center justify-center flex-shrink-0`}>
                    {edu.icon}
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold text-gray-900 dark:text-white">{edu.degree}</h4>
                    <p className="text-primary font-medium">{edu.institution}</p>
                    <p className="text-gray-400">{edu.location && `${edu.location} | `}{edu.period}</p>
                    <p className="text-gray-700 dark:text-gray-300 mt-2">{edu.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Certifications */}
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-6">Certifications</h3>
            
            {certifications.map((cert, index) => (
              <div key={index} className="glass-effect p-6 rounded-xl animate-slide-up" style={{ animationDelay: `${(index + 2) * 0.1}s` }}>
                <div className="flex items-start space-x-4">
                  <div className={`w-12 h-12 bg-gradient-to-r ${cert.gradient} rounded-full flex items-center justify-center flex-shrink-0`}>
                    {cert.icon}
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold text-gray-900 dark:text-white">{cert.title}</h4>
                    <p className="text-primary font-medium">{cert.organization}</p>
                    <p className="text-gray-400">{cert.date}</p>
                    <p className="text-gray-700 dark:text-gray-300 mt-2">{cert.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
